import React from 'react'
import ItemList from './components/ItemList'

function App() {
  return (
    
      FastAPI + MongoDB + React
      
    
  )
}

export default App