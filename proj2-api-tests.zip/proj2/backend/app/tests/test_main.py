def test_root_route():
    assert True